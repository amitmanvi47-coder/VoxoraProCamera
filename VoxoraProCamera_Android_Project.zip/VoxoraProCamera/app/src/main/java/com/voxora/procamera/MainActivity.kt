package com.voxora.procamera

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.video.FileOutputOptions
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private lateinit var previewView: PreviewView
    private lateinit var statusText: TextView
    private lateinit var shutterButton: TextView
    private lateinit var photoMode: TextView
    private lateinit var videoMode: TextView
    private lateinit var flashButton: TextView
    private lateinit var qualityButton: TextView
    private lateinit var zoomSeek: SeekBar
    private lateinit var zoomLabel: TextView
    private var camera: Camera? = null
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null
    private var lensFacing = CameraSelector.LENS_FACING_BACK
    private var isVideoMode = false
    private var flashOn = false
    private var highQuality = false
    private lateinit var cameraExecutor: ExecutorService

    private val permissions = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        if (result[Manifest.permission.CAMERA] == true) startCamera()
        else toast("Camera permission is needed to use the camera")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        setContentView(R.layout.activity_main)
        cameraExecutor = Executors.newSingleThreadExecutor()
        previewView = findViewById(R.id.previewView)
        statusText = findViewById(R.id.statusText)
        shutterButton = findViewById(R.id.shutterButton)
        photoMode = findViewById(R.id.photoMode)
        videoMode = findViewById(R.id.videoMode)
        flashButton = findViewById(R.id.flashButton)
        qualityButton = findViewById(R.id.qualityButton)
        zoomSeek = findViewById(R.id.zoomSeek)
        zoomLabel = findViewById(R.id.zoomLabel)

        photoMode.setOnClickListener { setMode(false) }
        videoMode.setOnClickListener { setMode(true) }
        shutterButton.setOnClickListener { if (isVideoMode) toggleVideo() else takePhoto() }
        findViewById<TextView>(R.id.switchButton).setOnClickListener {
            if (recording != null) { toast("Stop recording before switching camera"); return@setOnClickListener }
            lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK) CameraSelector.LENS_FACING_FRONT else CameraSelector.LENS_FACING_BACK
            startCamera()
        }
        flashButton.setOnClickListener {
            flashOn = !flashOn
            flashButton.alpha = if (flashOn) 1f else 0.65f
            flashButton.text = if (flashOn) "⚡ ON" else "⚡"
            camera?.cameraControl?.enableTorch(flashOn && lensFacing == CameraSelector.LENS_FACING_BACK)
            imageCapture?.flashMode = if (flashOn) ImageCapture.FLASH_MODE_ON else ImageCapture.FLASH_MODE_OFF
        }
        qualityButton.setOnClickListener {
            if (recording != null) { toast("Stop recording to change quality"); return@setOnClickListener }
            highQuality = !highQuality
            qualityButton.text = if (highQuality) "4K* 30" else "FHD 30"
            startCamera()
        }
        findViewById<TextView>(R.id.galleryButton).setOnClickListener {
            val intent = android.content.Intent(android.content.Intent.ACTION_VIEW, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
            try { startActivity(intent) } catch (_: Exception) { toast("Open Gallery from your phone") }
        }
        findViewById<TextView>(R.id.timerButton).setOnClickListener { toast("Timer control is a placeholder in this starter build") }
        zoomSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                val state = camera?.cameraInfo?.zoomState?.value ?: return
                val ratio = state.minZoomRatio + (state.maxZoomRatio - state.minZoomRatio) * progress / 100f
                camera?.cameraControl?.setZoomRatio(ratio)
                zoomLabel.text = "ZOOM  %.1f×".format(ratio)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        if (hasCameraPermission()) startCamera()
        else permissions.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO))
    }

    private fun hasCameraPermission() = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    private fun setMode(video: Boolean) {
        if (recording != null) { toast("Stop recording before changing mode"); return }
        isVideoMode = video
        photoMode.setBackgroundResource(if (video) R.drawable.control_pill else R.drawable.mode_selected)
        videoMode.setBackgroundResource(if (video) R.drawable.mode_selected else R.drawable.control_pill)
        photoMode.setTextColor(if (video) 0xFFFFFFFF.toInt() else 0xFF111111.toInt())
        videoMode.setTextColor(if (video) 0xFF111111.toInt() else 0xFFFFFFFF.toInt())
        statusText.text = if (video) "VIDEO READY • STABILIZATION IF SUPPORTED" else "READY • NATURAL COLOR PROFILE"
        shutterButton.contentDescription = if (video) "Start or stop video recording" else "Take photo"
    }

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            try {
                val provider = providerFuture.get()
                val selector = CameraSelector.Builder().requireLensFacing(lensFacing).build()
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                imageCapture = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                    .setFlashMode(if (flashOn) ImageCapture.FLASH_MODE_ON else ImageCapture.FLASH_MODE_OFF)
                    .build()
                val recorder = Recorder.Builder()
                    .setQualitySelector(QualitySelector.from(if (highQuality) Quality.UHD else Quality.FHD, QualitySelector.FALLBACK_STRATEGY_LOWER))
                    .build()
                videoCapture = VideoCapture.withOutput(recorder)
                provider.unbindAll()
                camera = provider.bindToLifecycle(this, selector, preview, imageCapture, videoCapture)
                val zoom = camera?.cameraInfo?.zoomState?.value
                zoomSeek.progress = 0
                zoomLabel.text = "ZOOM  %.1f×".format(zoom?.minZoomRatio ?: 1f)
                qualityButton.text = if (highQuality) "4K* 30" else "FHD 30"
                statusText.text = "CAMERA READY • ${if (lensFacing == CameraSelector.LENS_FACING_BACK) "REAR" else "FRONT"} LENS"
            } catch (e: Exception) {
                statusText.text = "CAMERA UNAVAILABLE"
                toast("Unable to start camera: ${e.localizedMessage ?: "unsupported camera"}")
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun takePhoto() {
        val capture = imageCapture ?: run { toast("Camera is starting"); return }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis())
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "VOXORA_$stamp")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/VoxoraPro")
        }
        val options = ImageCapture.OutputFileOptions.Builder(contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values).build()
        capture.takePicture(options, ContextCompat.getMainExecutor(this), object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                statusText.text = "PHOTO SAVED • PICTURES/VOXORAPRO"
                toast("Photo saved to Pictures/VoxoraPro")
            }
            override fun onError(exception: ImageCaptureException) { toast("Photo failed: ${exception.message}") }
        })
    }

    private fun toggleVideo() {
        val active = recording
        if (active != null) {
            active.stop()
            recording = null
            statusText.text = "SAVING VIDEO…"
            shutterButton.setBackgroundResource(android.R.color.transparent)
            return
        }
        val capture = videoCapture ?: run { toast("Video camera is starting"); return }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis())
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "VOXORA_$stamp")
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/VoxoraPro")
        }
        val output = MediaStoreOutputOptions.Builder(contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI).setContentValues(values).build()
        var pending = capture.output.prepareRecording(this, output)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) pending = pending.withAudioEnabled()
        recording = pending.start(ContextCompat.getMainExecutor(this)) { event ->
            when (event) {
                is VideoRecordEvent.Start -> {
                    statusText.text = "● RECORDING • TAP SHUTTER TO STOP"
                    toast("Recording started")
                }
                is VideoRecordEvent.Finalize -> {
                    recording = null
                    statusText.text = if (event.hasError()) "VIDEO SAVE ERROR" else "VIDEO SAVED • MOVIES/VOXORAPRO"
                    if (event.hasError()) toast("Video failed: ${event.error}") else toast("Video saved to Movies/VoxoraPro")
                }
            }
        }
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        super.onDestroy()
        if (::cameraExecutor.isInitialized) cameraExecutor.shutdown()
    }
}
