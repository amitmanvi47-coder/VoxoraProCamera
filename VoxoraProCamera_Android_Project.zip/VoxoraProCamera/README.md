# Voxora Pro Camera — Android Native Starter

A native Kotlin + CameraX camera app with a premium dark interface, photo capture, video recording, front/rear camera switching, torch/flash, zoom, and FHD/UHD quality selection based on device support.

## Requirements
- Android Studio (current stable)
- JDK 17
- Android SDK Platform 35
- Internet access for Gradle to download dependencies
- Android phone running Android 8.0 (API 26) or newer

## Build an APK
1. Extract `VoxoraProCamera.zip`.
2. Open the extracted `VoxoraProCamera` folder in Android Studio.
3. Allow Gradle Sync to finish. If prompted, install Android SDK 35 and JDK 17.
4. Connect your Android phone with USB debugging enabled, or use an emulator (real camera hardware is recommended).
5. Press **Run** to install and test.
6. For an APK: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
7. Android Studio shows a notification with **Locate**. The debug APK is usually at `app/build/outputs/apk/debug/app-debug.apk`.

## Included
- CameraX live preview
- High-quality JPEG still capture
- MP4 video recording with audio permission
- Camera switch, zoom slider, torch toggle
- FHD/UHD quality selector with CameraX fallback to lower quality
- Saves photos to `Pictures/VoxoraPro` and videos to `Movies/VoxoraPro`

## Important limits / honest labeling
- This is an app source project, not a precompiled APK. It must be built with Android Studio.
- The “4K*” option requests CameraX UHD quality; if unsupported, CameraX falls back to a lower supported quality. It does not guarantee 4K on every device.
- A third-party app cannot make a phone's sensor/lens equal to an iPhone. Final image quality depends on the phone's sensor, optics, ISP, and supported camera capabilities.
- This starter build does not implement Apple's proprietary image pipeline, true multi-frame Smart HDR, Cinematic mode depth segmentation, ProRes, or a full computational photography pipeline.
- The timer button currently shows a placeholder message. Exposure controls, advanced manual ISO/shutter/focus, RAW/DNG, stabilization selection, gallery thumbnails, and a full editing pipeline are future enhancements.
- Test camera/video behavior on your specific phone before publishing. Some vendors limit camera combinations, resolutions, flash, or audio behavior.

## Troubleshooting
- If Gradle sync fails, check network access and ensure Android Studio uses JDK 17.
- If camera preview fails, grant Camera permission in Android settings and restart the app.
- If UHD is unavailable, the selector falls back to a lower supported resolution.
